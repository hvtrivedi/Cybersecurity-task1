# 🔐 Cyber Security Internship – Task 1  

## Task: Scan Your Local Network for Open Ports  

### 🎯 Objective  
To perform basic network reconnaissance using **Nmap**, identify open ports and services on the local network, and understand potential security risks.  

---

### 🛠 Tools Used  
- **Nmap** (for scanning)  
- **Wireshark** (optional, for packet analysis)  
- **Windows PowerShell / Linux Terminal**  

---

### 📌 Steps Performed  

1. **Installed Nmap** from the official site.  
2. Found my local IP range using:  
   ```bash
   ipconfig  (Windows)
   ifconfig  (Linux/Mac)
   ```  
   Example range: `192.168.1.0/24`  

3. Ran a TCP SYN scan:  
   ```bash
   nmap -sS 192.168.1.0/24
   ```  

4. **Observed Results** – Identified multiple devices with open ports (e.g., 22, 80, 443, 3389).  

5. **Analyzed Services**:  
   - **22 (SSH)** → Secure remote login  
   - **80 (HTTP)** → Web services  
   - **443 (HTTPS)** → Encrypted web services  
   - **3389 (RDP)** → Remote Desktop Protocol  

6. Used **Wireshark** to capture traffic and confirm requests/responses.  

---

### 📊 Results (Sample Output)  

Example Nmap Output:  
```
Nmap scan report for 192.168.1.5
Host is up (0.0021s latency).
Not shown: 996 closed ports
PORT     STATE SERVICE
22/tcp   open  ssh
80/tcp   open  http
443/tcp  open  https
3389/tcp open  ms-wbt-server
```

---

### 🔍 Analysis of Security Risks  
- **SSH (22)**: Brute force attacks possible if weak passwords are used.  
- **HTTP (80)**: Unencrypted communication, vulnerable to sniffing.  
- **HTTPS (443)**: Safer but still needs proper TLS configuration.  
- **RDP (3389)**: Common attack target for ransomware and brute-force attempts.  

---

### ✅ Recommendations  
- Disable unused ports.  
- Enforce strong passwords and key-based authentication for SSH.  
- Redirect or restrict RDP access with a VPN.  
- Use a firewall to filter traffic.  
- Regularly patch and update services.  

---

### 📁 Repository Contents  
- `scan_results.txt` → Saved Nmap results  
- `screenshots/` → Screenshots of scans and Wireshark captures  
- `README.md` → Explanation (this document)  

---

### 📝 Interview Question Prep  
1. **What is an open port?** – A network port actively accepting connections.  
2. **How does Nmap perform a TCP SYN scan?** – Sends SYN packets and checks for SYN-ACK responses.  
3. **What risks are associated with open ports?** – Unauthorized access, data leaks, brute force attacks.  
4. **Difference between TCP and UDP scanning?** – TCP checks connections, UDP scans for datagram-based services.  
5. **How to secure open ports?** – Close unused ones, use firewalls, enable encryption.  
6. **Firewall’s role?** – Controls traffic by filtering ports and protocols.  
7. **What is port scanning?** – Technique to discover open services on a host, used by attackers for reconnaissance.  
8. **How does Wireshark help?** – Provides deep packet inspection to validate traffic on open ports.  

---

### 📤 Submission  
Upload this repo to GitHub with:  
- **Nmap scan results**  
- **Screenshots**  
- **This README file**  

Then paste the GitHub link into the given **Google Form**.  
